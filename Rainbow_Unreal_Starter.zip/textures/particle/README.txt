Put supported particle textures here. Particle visuals and rain behavior have engine limitations.
