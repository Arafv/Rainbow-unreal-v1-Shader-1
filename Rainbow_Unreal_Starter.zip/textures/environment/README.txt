Put supported environment/sky textures here. Exact texture paths and available overrides depend on Bedrock version.
