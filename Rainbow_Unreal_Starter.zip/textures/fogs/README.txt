Fog definitions are in the root-level fogs/ folder, not this textures folder. This note is included only to avoid confusion.
