Put supported custom block textures here. Match the exact vanilla texture names and formats for your Bedrock version.
