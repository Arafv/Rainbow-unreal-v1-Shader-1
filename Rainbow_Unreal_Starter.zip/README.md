# Rainbow Unreal — Bedrock Resource Pack Starter

This is a starter resource-pack structure for Minecraft Bedrock Edition.
It intentionally does **not** include Vibrant Visuals / Deferred rendering files,
patched-client files, or a custom pack icon. Add `pack_icon.png` later if desired.

## Included
- `manifest.json`: resource-pack manifest
- `fogs/underwater_blue_fog.json`: an example custom fog definition
- Asset folders for future textures and animations

## Important compatibility notes
A fog definition is only a definition; it is not automatically applied everywhere.
Applying it to specific biomes or dimensions may require compatible biome/client
definitions and support from the exact Bedrock version. Test changes in-game.
A normal resource pack cannot provide every traditional shader effect. True
volumetric clouds, custom real-time lighting/shadows, water refraction, and
fully procedural auroras/black holes are not generally available through a
conventional vanilla resource pack alone.

## Folder layout
- `textures/blocks/`: block textures (some Bedrock versions/assets use different naming)
- `textures/environment/`: environment and sky-related textures where supported
- `textures/particle/`: particle textures where supported
- `animations/`: supported texture animation metadata/assets
- `fogs/`: fog definitions

## Install on Android
1. Download the ZIP and extract it.
2. Open the extracted `Rainbow_Unreal_Starter` folder.
3. Zip the *contents* of that folder (so `manifest.json` is at the ZIP root), then rename the ZIP to `Rainbow_Unreal_Starter.mcpack`.
   Alternatively, use a file manager that can import a resource-pack folder directly.
4. Tap the `.mcpack` file and open it with Minecraft.
5. Enable it under Settings → Global Resources, or in a world's Resource Packs.

If Minecraft rejects the pack, check the import error and the exact game version before adding more files.
The `pack_icon.png` is optional and can be added later.
