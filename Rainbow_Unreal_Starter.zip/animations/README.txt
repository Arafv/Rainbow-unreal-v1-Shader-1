Put supported texture animation metadata and assets here. This folder alone does not make blocks or plants wave.
